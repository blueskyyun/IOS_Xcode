//
//  AppArchiver.swift
//  LoginDemo
//
//  Created by Groom on 2019/5/8.
//  Copyright © 2019年 Groom. All rights reserved.
//


import Foundation

class AppArchiver{
    
    //let path =
    static let share = AppArchiver()
    private var fileURL:URL
    
    init(){
        let urls = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        fileURL = (urls.first?.appendingPathComponent("appdata.archive"))!
    }
    
    func write(userInfo: LoginUserInfo)
    {
        
        //let data = NSMutableData()
        do {
            let data = try! NSKeyedArchiver.archivedData(withRootObject: userInfo)
            //archiver.encode(userInfo, forKey: "userInfo")
            //archiver.finishEncoding()
            try data.write(to: fileURL)
            
        } catch {
            print("Couldn't write to save file: " + error.localizedDescription)
        }
        
        
    }
    
    func read() -> LoginUserInfo? {
        
        
//        if let codedData = NSData(contentsOf: fileURL){
//        
//     
//    
//        do{
////            let data = Data(referencing:codedData)
//        let userInfo =  try NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(codedData as Data) as? LoginUserInfo
//        }catch{}
//        }
        
        let codedData = try?Data(contentsOf: fileURL)
        let userInfo = try?NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(codedData as! NSData) as! LoginUserInfo
        
        return userInfo!
        
    }
}

