//
//  MainViewController.swift
//  LoginDemo
//
//  Created by Groom on 2019/5/8.
//  Copyright © 2019年 Groom. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {
    @IBOutlet weak var userName: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let userinfo = AppArchiver.share.read()
        userName.text = userinfo?.userName
        // Do any additional setup after loading the view.
    }
    
    
}


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


